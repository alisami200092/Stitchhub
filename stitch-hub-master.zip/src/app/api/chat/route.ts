import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { messages } = body;

    // Hit your local Ollama server
    const response = await fetch("http://localhost:11434/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "stitchhub_v5", // Targeting your fine-tuned GGUF!
        messages: messages,
        stream: false, 
      }),
    });

    const data = await response.json();

    // Send the AI's reply back to the React frontend
    return NextResponse.json({ reply: data.message.content });
    
  } catch (error) {
    console.error("Ollama Connection Error:", error);
    return NextResponse.json(
      { error: "Failed to connect to local AI agent." },
      { status: 500 }
    );
  }
}