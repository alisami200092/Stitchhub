"use client";

import React, { useEffect, useState } from "react";
import { createClient } from "@/utils/supabase/client";
import { useChat } from "@/hooks/useChat";

type ActiveTab = "inbox" | "account" | "security" | "ledger";

export default function PartnerDashboardPage() {
  const supabase = createClient();
  const [activeTab, setActiveTab] = useState<ActiveTab>("inbox");
  const [user, setUser] = useState<any>(null);
  
  // Database-synced chat hook
  const { threads, activeThread, setActiveThreadId, sendMessage, isTyping } = useChat();
  const [chatInput, setChatInput] = useState("");

  useEffect(() => {
    async function getUser() {
      const { data } = await supabase.auth.getUser();
      setUser(data.user);
    }
    getUser();
  }, [supabase]);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isTyping) return;
    sendMessage(chatInput);
    setChatInput(""); 
  };

  return (
    <div className="min-h-screen w-full bg-[#090a0f] text-zinc-100 pt-28 pb-16 px-4 sm:px-6 lg:px-12">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="border-b border-zinc-800/80 pb-6 mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold font-display text-white">Partner Workspace</h1>
            <p className="text-xs text-zinc-500 mt-1">Manage your account, view order history, and track messages.</p>
          </div>
          {user && (
            <div className="flex items-center gap-2 bg-[#121316] border border-zinc-800/80 px-3.5 py-1.5 rounded-xl text-[11px] font-mono tracking-wide text-zinc-400">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Account ID: <span className="text-zinc-200">{user.id?.slice(0, 8)}</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* ─────────────────────────────────────────────────────────────
              🗂️ LEFT NAVIGATION (Fully Restored Side Panel Tabs)
             ───────────────────────────────────────────────────────────── */}
          <div className="lg:col-span-3 flex flex-col space-y-2">
            <button 
              onClick={() => setActiveTab("inbox")} 
              className={`w-full text-left px-4 py-3.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-3 ${
                activeTab === "inbox" 
                  ? "bg-[#121316] text-white border-zinc-700 shadow-xl" 
                  : "bg-transparent text-zinc-400 border-transparent hover:bg-zinc-900/40 hover:text-zinc-200"
              }`}
            >
              <svg className="h-4 w-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0a2 2 0 01-2 2H6a2 2 0 01-2-2m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414a1 1 0 00-.707-.293H4" />
              </svg>
              My Inbox
            </button>

            <button 
              onClick={() => setActiveTab("account")} 
              className={`w-full text-left px-4 py-3.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-3 ${
                activeTab === "account" 
                  ? "bg-[#121316] text-white border-zinc-700 shadow-xl" 
                  : "bg-transparent text-zinc-400 border-transparent hover:bg-zinc-900/40 hover:text-zinc-200"
              }`}
            >
              <svg className="h-4 w-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              Profile Settings
            </button>

            <button 
              onClick={() => setActiveTab("security")} 
              className={`w-full text-left px-4 py-3.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-3 ${
                activeTab === "security" 
                  ? "bg-[#121316] text-white border-zinc-700 shadow-xl" 
                  : "bg-transparent text-zinc-400 border-transparent hover:bg-zinc-900/40 hover:text-zinc-200"
              }`}
            >
              <svg className="h-4 w-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
              Security & 2FA
            </button>

            <button 
              onClick={() => setActiveTab("ledger")} 
              className={`w-full text-left px-4 py-3.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-3 ${
                activeTab === "ledger" 
                  ? "bg-[#121316] text-white border-zinc-700 shadow-xl" 
                  : "bg-transparent text-zinc-400 border-transparent hover:bg-zinc-900/40 hover:text-zinc-200"
              }`}
            >
              <svg className="h-4 w-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
              </svg>
              Order History
            </button>
          </div>

          {/* Right Main Panel Container */}
          <div className="lg:col-span-9 bg-[#121316] border border-zinc-800 rounded-2xl p-6 min-h-[60vh] shadow-2xl">
            
            {/* 📥 INBOX VIEW CONTENT */}
            {activeTab === "inbox" && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 h-full">
                
                {/* Left Column: Thread List */}
                <div className="md:col-span-5 border-r border-zinc-800/60 pr-2 space-y-3 max-h-[55vh] overflow-y-auto custom-scrollbar">
                  <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Message Threads</h3>
                  
                  {threads.length === 0 ? (
                    <div className="text-xs text-zinc-600 font-mono text-center py-12">No messages yet.</div>
                  ) : (
                    threads.map((thread) => (
                      <div 
                        key={thread.id} 
                        onClick={() => setActiveThreadId(thread.id)} 
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                          activeThread?.id === thread.id 
                            ? "bg-[#090a0f] border-[#d4af37]" 
                            : "bg-zinc-900/40 border-zinc-800/60 hover:border-zinc-700"
                        }`}
                      >
                        <p className={`text-xs font-bold truncate ${activeThread?.id === thread.id ? "text-white" : "text-zinc-300"}`}>{thread.subject}</p>
                        <p className="text-[11px] text-zinc-500 truncate mt-1.5">
                          {thread.messages[thread.messages.length - 1]?.content}
                        </p>
                      </div>
                    ))
                  )}
                </div>

                {/* Right Column: Active Chat Feed */}
                <div className="md:col-span-7 flex flex-col h-full max-h-[55vh]">
                  {activeThread ? (
                    <>
                      <div className="border-b border-zinc-800 pb-3 flex justify-between items-center">
                        <div>
                          <span className="text-[9px] font-mono text-[#d4af37] uppercase tracking-wider">Active Thread</span>
                          <h2 className="text-sm font-bold text-white mt-0.5">{activeThread.subject}</h2>
                        </div>
                        <span className={`text-[9px] uppercase tracking-wider px-2 py-0.5 font-bold rounded border ${
                          activeThread.status === "Review Required" 
                            ? "bg-red-950/30 border-red-900/40 text-red-400" 
                            : "bg-emerald-950/30 border-emerald-900/40 text-emerald-400"
                        }`}>
                          {activeThread.status}
                        </span>
                      </div>

                      {/* Messages Feed */}
                      <div className="flex-1 overflow-y-auto space-y-4 py-4 pr-2 custom-scrollbar">
                        {activeThread.messages.map((msg, idx) => (
                          <div key={idx} className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}>
                            <div className={`p-3.5 rounded-xl max-w-[85%] text-xs leading-relaxed ${
                              msg.role === "user" 
                                ? "bg-[#d4af37] text-[#090a0f] font-medium" 
                                : "bg-zinc-900/50 border border-zinc-800/80 text-zinc-300 font-body whitespace-pre-wrap"
                            }`}>
                              {msg.content}
                            </div>
                          </div>
                        ))}
                        
                        {/* 🌟 STYLISH TYPING ANIMATION */}
                        {isTyping && (
                          <div className="flex items-center gap-2.5 px-1 animate-scaleIn">
                            <div className="h-5 w-5 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/5 flex items-center justify-center shrink-0">
                              <svg className="animate-spin h-3 w-3 text-[#d4af37]" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                              </svg>
                            </div>
                            <span className="text-[11px] font-mono tracking-wider text-[#d4af37]/80 animate-pulse bg-[#d4af37]/5 border border-[#d4af37]/10 px-2 py-0.5 rounded">
                              Verifying order specs against factory floor capacity...
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Reply Box Form */}
                      <form onSubmit={handleChatSubmit} className="pt-4 border-t border-zinc-800/60 mt-auto flex items-center gap-3">
                        <div className="relative flex-1">
                          <input 
                            type="text" 
                            value={chatInput} 
                            onChange={(e) => setChatInput(e.target.value)} 
                            disabled={isTyping}
                            placeholder="Reply to AI Agent..." 
                            className="w-full bg-[#090a0f] border border-zinc-800 text-zinc-200 text-xs rounded-xl pl-4 pr-12 py-3.5 focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] outline-none transition-all"
                          />
                        </div>
                        
                        {/* 🌟 THE GOLDEN SUBMIT BUTTON */}
                        <button
                          type="submit"
                          disabled={isTyping || !chatInput.trim()}
                          className="h-11 px-5 rounded-xl bg-[#d4af37] text-[#090a0f] font-bold text-xs uppercase tracking-wider flex items-center justify-center transition-all hover:bg-[#bfa032] disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_0_15px_rgba(212,175,55,0.15)] hover:shadow-[0_0_20px_rgba(212,175,55,0.3)]"
                        >
                          Send
                        </button>
                      </form>
                    </>
                  ) : (
                    <div className="h-full flex items-center justify-center text-xs text-zinc-600 font-mono py-24">Select a thread.</div>
                  )}
                </div>
              </div>
            )}

            {/* Placeholder screens for your other tabs so they don't break */}
            {activeTab === "account" && (
              <div className="animate-scaleIn space-y-4">
                <h2 className="text-base font-bold text-white font-display">Profile Settings</h2>
                <p className="text-xs text-zinc-500">Configuration nodes for corporate identity and routing proxies.</p>
                <div className="h-40 border border-dashed border-zinc-800 rounded-xl flex items-center justify-center text-xs text-zinc-600 font-mono">Form Fields Mount Point</div>
              </div>
            )}

            {activeTab === "security" && (
              <div className="animate-scaleIn space-y-4">
                <h2 className="text-base font-bold text-white font-display">Two-Factor Authentication & Cryptographic Keys</h2>
                <p className="text-xs text-zinc-500">Secure your B2B operations connection.</p>
                <div className="h-40 border border-dashed border-zinc-800 rounded-xl flex items-center justify-center text-xs text-zinc-600 font-mono">2FA Security Matrix Settings</div>
              </div>
            )}

            {activeTab === "ledger" && (
              <div className="animate-scaleIn space-y-4">
                <h2 className="text-base font-bold text-white font-display">Historical Sourcing Manifest Order History</h2>
                <p className="text-xs text-zinc-500">Archive logs of previous custom asset procurements.</p>
                <div className="h-40 border border-dashed border-zinc-800 rounded-xl flex items-center justify-center text-xs text-zinc-600 font-mono">No historical manifests archived for this account token.</div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}