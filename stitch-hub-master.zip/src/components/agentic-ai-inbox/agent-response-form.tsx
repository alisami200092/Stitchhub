"use client";

import React, { useRef } from "react";

interface CheckoutFormProps {
  toEmail: string;
  setToEmail: (val: string) => void;
  subject: string;
  setSubject: (val: string) => void;
  message: string;
  setMessage: (val: string) => void;
  attachedFiles: File[];
  setAttachedFiles: (files: File[]) => void;
}

export default function CheckoutForm({
  toEmail,
  setToEmail,
  subject,
  setSubject,
  message,
  setMessage,
  attachedFiles,
  setAttachedFiles,
}: CheckoutFormProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      setAttachedFiles([...attachedFiles, ...filesArray]);
    }
  };

  return (
    <div className="space-y-6 animate-scaleIn h-full flex flex-col">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Target Routing
          </label>
          <input
            type="email"
            value={toEmail}
            onChange={(e) => setToEmail(e.target.value)}
            className="w-full bg-[#121316] border border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-200 focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] focus:outline-none transition-all"
            placeholder="Enter sourcing email address"
          />
        </div>
        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Subject Line
          </label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full bg-[#121316] border border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-200 focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37] focus:outline-none transition-all"
            placeholder="Enter quote request subject title"
          />
        </div>
      </div>

      {/* Editor Toolbar */}
      <div className="flex items-center gap-1.5 border-b border-zinc-800 pb-3">
        {["B", "I", "U", "U2", ">", "S", "⋮"].map((action, i) => (
          <button
            key={i}
            type="button"
            className="h-8 w-8 flex items-center justify-center rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600 transition-colors text-xs font-bold cursor-pointer"
          >
            {action === "U2" ? <span className="underline decoration-double">U</span> : action}
          </button>
        ))}
      </div>

      {/* Message Editor */}
      <div className="flex-1 min-h-75">
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="w-full h-full border rounded-xl p-5 text-sm leading-relaxed font-body focus:outline-none resize-none transition-all duration-300 bg-[#121316]/50 border-zinc-800 text-zinc-300 focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37]"
          placeholder="Include any specific printing limitations, timelines, or custom logic..."
        />
      </div>

      {/* File Attachments Zone */}
      <div>
        <input type="file" ref={fileInputRef} onChange={handleFileChange} multiple className="hidden" />
        <button
          onClick={() => fileInputRef.current?.click()}
          type="button"
          className="w-full border border-dashed border-zinc-800 rounded-xl p-4 flex items-center justify-center hover:border-[#d4af37]/50 hover:bg-[#d4af37]/5 transition-all cursor-pointer group"
        >
          <span className="flex items-center gap-2.5 text-xs text-zinc-400 group-hover:text-[#d4af37] font-medium transition-colors">
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
            </svg>
            Attach Artwork Mockups or Sourcing Worksheets
          </span>
        </button>
      </div>
    </div>
  );
}