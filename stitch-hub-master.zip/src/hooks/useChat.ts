"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/utils/supabase/client";

export type Message = {
  role: "user" | "assistant";
  content: string;
};

export type ChatThread = {
  id: string;
  subject: string;
  status: "Draft Ready" | "Review Required";
  messages: Message[];
};

export function useChat() {
  const supabase = createClient();
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState<boolean>(false);

  // 1. Fetch historical threads from Supabase (email_logs) on load
  useEffect(() => {
    const fetchThreads = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("email_logs")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (data && !error) {
        // Map old columns into the multi-turn Chat format
        const formattedThreads = data.map((log: any) => {
          let history: Message[] = [];
          
          try {
            // Try to parse if we already saved a multi-turn array here
            const parsed = JSON.parse(log.ai_response_draft);
            if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].role) {
              history = parsed;
            } else {
              throw new Error("Not a chat array");
            }
          } catch {
            // Fallback for new checkouts (Initial 2-turn format)
            history = [
              { role: "user", content: log.body || "" },
              { role: "assistant", content: log.ai_response_draft || "No response generated." }
            ];
          }

          return {
            id: log.id,
            subject: log.subject,
            // 👇 We just add the "as" cast to the end of this line!
            status: (log.status === "escalated" ? "Review Required" : "Draft Ready") as "Review Required" | "Draft Ready",
            messages: history
          };
        });

        setThreads(formattedThreads);
        if (formattedThreads.length > 0) setActiveThreadId(formattedThreads[0].id);
      }
    };
    fetchThreads();
  }, [supabase]);

  const activeThread = threads.find((t) => t.id === activeThreadId);

  // 2. Send message, get AI reply, and update Supabase
  const sendMessage = async (content: string) => {
    if (!content.trim() || !activeThread) return;

    const userMessage: Message = { role: "user", content };
    const updatedMessages = [...activeThread.messages, userMessage];

    // Optimistic UI Update
    setThreads((prev) =>
      prev.map((t) => (t.id === activeThreadId ? { ...t, messages: updatedMessages } : t))
    );
    setIsTyping(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: updatedMessages }),
      });

      const data = await response.json();
      const aiMessage: Message = { role: "assistant", content: data.reply };
      const finalMessages = [...updatedMessages, aiMessage];

      // Update UI with AI reply
      setThreads((prev) =>
        prev.map((t) => (t.id === activeThreadId ? { ...t, messages: finalMessages } : t))
      );

      // Save the multi-turn array back to the text column as a JSON string!
      await supabase
        .from("email_logs")
        .update({ ai_response_draft: JSON.stringify(finalMessages) })
        .eq("id", activeThreadId);

    } catch (error) {
      console.error("Chat Error:", error);
    } finally {
      setIsTyping(false);
    }
  };

  return { threads, activeThread, setActiveThreadId, sendMessage, isTyping };
}