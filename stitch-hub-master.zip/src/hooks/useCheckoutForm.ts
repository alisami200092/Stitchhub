"use client";


import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useCartStore } from "../stores/cart-store";
import { useCheckoutFormStore, generateMessageFromCart } from "../stores/checkout-form-store";
import { createClient } from "@/utils/supabase/client";

export function useCheckoutForm() {
  const router = useRouter();
  const supabase = createClient();
  const cart = useCartStore((s) => s.cart);
  const clearCart = useCartStore((s) => s.clearCart);
  
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);

  const {
    toEmail,
    subject,
    message,
    isSubmitting,
    isSuccess,
    setToEmail,
    setSubject,
    setMessage,
    setIsSubmitting,
    setIsSuccess,
  } = useCheckoutFormStore();

  // Sync the message text area with a cart-derived template whenever the cart changes
  useEffect(() => {
    setMessage(generateMessageFromCart(cart));
  }, [cart, setMessage]);

  // 🚀 THE NEW LOGIC: POST to Ollama -> Save to Supabase -> Teleport to Profile
  const handleSubmit = async () => {
    if (!message.trim()) {
      alert("Your sourcing manifest is currently empty. Add catalog styles or type a request before optimization.");
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Identify the User
      const { data: { user } } = await supabase.auth.getUser();

      // 2. Ping your local StitchHub v5 model (using the Next.js proxy route)
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [{ role: "user", content: message }],
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "An integration failure occurred during local agent processing.");
      }

      // 3. Save to Supabase (Targeting your existing email_logs table!)
      const { error } = await supabase.from("email_logs").insert({
        user_id: user?.id,
        subject: subject,
        body: message, // Your DB uses 'body' for the initial user request
        ai_response_draft: data.reply, // Your DB uses this for the AI's reply
        status: data.reply.includes("50 units") || data.reply.includes("4-week") 
          ? "escalated"  // Match your existing DB status strings
          : "approved",
      });

      if (error) {
        console.error("Supabase Save Error:", error);
        throw new Error("Failed to secure thread to database.");
      }

      // 4. Clean up the cart so it's empty for the next order
      clearCart();
      setAttachedFiles([]);
      setIsSuccess(true); 

      // 5. Teleport the user to their live inbox!
      router.push("/profile");

    } catch (err) {
      console.error("Agent communication failure:", err);
      const errMsg = err instanceof Error ? err.message : "Network Timeout";
      alert(`AI Operations Node Exception: ${errMsg}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    cart,
    toEmail,
    setToEmail,
    subject,
    setSubject,
    isSubmitting,
    isSuccess,
    message,
    setMessage,
    handleSubmit,
    attachedFiles,
    setAttachedFiles,
  };
}